﻿#include <windows.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>

using namespace std;

// Функция для преобразования числа из десятичной системы в другую
string fromDecimal(int number, int base)
{
    string result = "";
    while (number > 0)
    {
        int remainder = number % base;
        if (remainder < 10)
            result = char('0' + remainder) + result;
        else
            result = char('A' + remainder - 10) + result;
        number /= base;
    }
    return result;
}

// Функция для преобразования числа из другой системы в десятичную
int toDecimal(string number, int base)
{
    int result = 0;
    for (size_t i = 0; i < number.length(); i++)
    {
        char ch = number[i];
        int digit = (ch >= '0' && ch <= '9') ? ch - '0' : ch - 'A' + 10;
        result = result * base + digit;
    }
    return result;
}

// Функция для преобразования дробных чисел из десятичной системы в другую
string fromDecimalFraction(double number, int base, int precision)
{
    string result = ".";
    for (int i = 0; i < precision; i++)
    {
        number *= base;
        int digit = int(number);
        if (digit < 10)
            result += char('0' + digit);
        else
            result += char('A' + digit - 10);
        number -= digit;
    }
    return result;
}

// Функция для преобразования двоичной системы в восьмеричную и шестнадцатеричную
string binaryToOctal(string binary)
{
    while (binary.length() % 3 != 0)
        binary = '0' + binary;
    string result = "";
    for (size_t i = 0; i < binary.length(); i += 3)
    {
        string triplet = binary.substr(i, 3);
        result += fromDecimal(toDecimal(triplet, 2), 8);
    }
    return result;
}

string binaryToHex(string binary)
{
    while (binary.length() % 4 != 0)
        binary = '0' + binary;
    string result = "";
    for (size_t i = 0; i < binary.length(); i += 4)
    {
        string quartet = binary.substr(i, 4);
        result += fromDecimal(toDecimal(quartet, 2), 16);
    }
    return result;
}

// Функция для упорядочивания чисел
void sortNumbers()
{
    int num1 = toDecimal("76", 16);
    int num2 = toDecimal("367", 8);
    int num3 = toDecimal("11011001", 2);
    int num4 = 152;

    int numbers[] = { num1, num2, num3, num4 };
    sort(numbers, numbers + 4);

    cout << "Упорядоченные числа: ";
    for (int i = 0; i < 4; i++)
    {
        cout << numbers[i] << " ";
    }
    cout << "\n";
}

// Функция для вычисления количества различных положительных чисел
int countNumbers(int k, int r)
{
    return pow(r, k);
}

// Функция для арифметического сдвига числа влево и вправо
void arithmeticShift(int number, int shift)
{
    cout << "Исходное число: " << number << " (" << fromDecimal(number, 2) << ")\n";
    int shiftedLeft = number << shift;
    cout << "Сдвиг влево: " << shiftedLeft << " (" << fromDecimal(shiftedLeft, 2) << ")\n";
    int shiftedRight = number >> shift;
    cout << "Сдвиг вправо: " << shiftedRight << " (" << fromDecimal(shiftedRight, 2) << ")\n";
}

int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    int choice = 0;
    while (true)
    {
        cout << "Выберите задачу:\n";
        cout << "1. Преобразование из десятичной системы в другую\n";
        cout << "2. Преобразование из другой системы в десятичную\n";
        cout << "3. Преобразование дробных чисел из десятичной системы\n";
        cout << "4. Преобразование двоичной системы в восьмеричную и шестнадцатеричную\n";
        cout << "5. Упорядочивание чисел\n";
        cout << "6. Количество различных положительных чисел\n";
        cout << "7. Арифметический сдвиг числа\n";
        cout << "0. Выход\n";
        cout << "Ваш выбор: ";
        cin >> choice;

        if (choice == 1)
        {
            int number, base;
            cout << "Введите число в десятичной системе: ";
            cin >> number;
            cout << "Введите основание системы счисления (2, 5, 8, 16): ";
            cin >> base;
            cout << "Результат: " << fromDecimal(number, base) << "\n";
        }
        else if (choice == 2)
        {
            string number;
            int base;
            cout << "Введите число: ";
            cin >> number;
            cout << "Введите основание системы счисления (2, 5, 8, 16): ";
            cin >> base;
            cout << "Результат: " << toDecimal(number, base) << "\n";
        }
        else if (choice == 3)
        {
            double number;
            int base, precision;
            cout << "Введите дробное число в десятичной системе: ";
            cin >> number;
            cout << "Введите основание системы счисления (5, 8): ";
            cin >> base;
            cout << "Введите точность (количество знаков после запятой): ";
            cin >> precision;
            cout << "Результат: " << fromDecimalFraction(number, base, precision) << "\n";
        }
        else if (choice == 4)
        {
            string binary;
            cout << "Введите число в двоичной системе: ";
            cin >> binary;
            cout << "В восьмеричной системе: " << binaryToOctal(binary) << "\n";
            cout << "В шестнадцатеричной системе: " << binaryToHex(binary) << "\n";
        }
        else if (choice == 5)
        {
            sortNumbers();
        }
        else if (choice == 6)
        {
            int k, r;
            cout << "Введите количество разрядов (k): ";
            cin >> k;
            cout << "Введите основание системы счисления (r): ";
            cin >> r;
            cout << "Количество различных положительных чисел: " << countNumbers(k, r) << "\n";
        }
        else if (choice == 7)
        {
            int number, shift;
            cout << "Введите число: ";
            cin >> number;
            cout << "Введите количество сдвигов: ";
            cin >> shift;
            arithmeticShift(number, shift);
        }
        else if (choice == 0)
        {
            break;
        }
        else
        {
            cout << "Неверный выбор. Попробуйте снова.\n";
        }

        cin.get();
        cin.get();
    }

    return 0;
}